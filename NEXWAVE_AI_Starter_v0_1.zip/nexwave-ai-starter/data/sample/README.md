Sample-data folder. The notebook creates synthetic data during execution. Do not commit large IQ recordings here.
